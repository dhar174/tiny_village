import json
import os
from pathlib import Path
import sys
sys.path.insert(0, '/workspace/tiny_village')
from tests.subprocess_capture import capture_python
root = Path('/workspace/scratch/issue-736/execution/graph-validation/dev')
env = os.environ.copy()
env.update(TINY_TEST_ARTIFACT_DIR=str(root/'captures'), SDL_VIDEODRIVER='dummy',
    SDL_AUDIODRIVER='dummy', PYGAME_HIDE_SUPPORT_PROMPT='1',
    PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2')
sources = {
    'goap-error-handling': '''import unittest
suite = unittest.defaultTestLoader.loadTestsFromName('tests.test_goap_error_handling')
result = unittest.TextTestRunner(verbosity=2).run(suite)
assert result.testsRun == 5 and not result.skipped
raise SystemExit(not result.wasSuccessful())
''',
    'existing-planner-integration': '''import pytest
raise SystemExit(pytest.main(['-q', 'tests/test_goap_planner_integration_real.py']))
''',
}
rows = []
for name, source in sources.items():
    source_path = root/(name+'.source.txt')
    source_path.write_text(source)
    captured = capture_python(source, cwd=Path('/workspace/tiny_village'), env=env,
        test_id='issue736.existing.'+name, fatal_timeout=20, timeout=25)
    row = {'name': name, 'source': str(source_path), 'profile': 'dev',
        'interpreter': sys.executable, 'returncode': captured.completed.returncode,
        'artifact_dir': str(captured.artifact_dir)}
    rows.append(row)
    print(json.dumps(row))
    print(captured.completed.stdout[-2000:])
    print(captured.completed.stderr[-2200:])
(root/'existing-results.json').write_text(json.dumps(rows, indent=2)+'\n')
