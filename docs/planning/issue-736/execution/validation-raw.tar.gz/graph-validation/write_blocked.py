from pathlib import Path
import textwrap

root = Path('/workspace/tiny_village/docs/planning/issue-736/execution/blocked')
setup = '''"""Required #736 contract; run from repository root with python < this file.

This is intentionally retained outside test discovery because the required
contract is unresolved. A failing run is a blocker, never passing coverage.
"""
import inspect
import json
import logging
import random
from unittest.mock import patch
logging.basicConfig(level=logging.ERROR)
random.seed(736)
from actions import Action, Condition, State
from tiny_characters import Character, Goal
from tiny_gameplay_controller import GameplayController
from tiny_goap_system import GOAPPlanner, Plan
from tiny_graph_manager import GraphManager
from networkx import MultiDiGraph

graph = GraphManager()
controller = GameplayController(graph, {
    'headless': True, 'memory': {'mode': 'basic'},
    'characters': {'count': 1, 'use_llm': False, 'use_custom': True,
        'character_data': [{'name': 'ContractActor', 'age': 30,
            'job': 'unemployed', 'energy': 20}]},
    'checkpoint': {'auto_enabled': False}})
try:
    character = controller.characters['ContractActor']
    assert isinstance(character, Character) and character._initialized
    assert isinstance(graph.G, MultiDiGraph)
    assert graph.characters[character.name] is character
    assert any(node is character for node in graph.G)
    planner = GOAPPlanner(graph)
'''
goal = '''condition = Condition('energy_target', 'energy', character, 30)
goal = Goal('Recover energy', character, character, 1, 'recover',
    {False: [condition]}, None, None, None, None, None, None, [],
    graph, 'Basic Needs', {'energy': 30})
'''
action = '''action = Action('GraphRecovery', [],
    [{'targets': ['initiator'], 'attribute': 'energy', 'change_value': 10}],
    cost=1, initiator=character, graph_manager=graph)
'''
cases = {
'planner_goal_container': goal + '''print(json.dumps({'condition_passes': condition.check_condition(),
    'condition_container': type(goal.completion_conditions[False]).__name__,
    'expected_completion': False}), flush=True)
assert goal.check_completion() is False
character.energy = 30
assert character.energy >= 30
assert goal.check_completion() is True
''',
'planner_goal_signature': goal + '''state = State({'energy': 30})
actual = planner._goal_satisfied(goal, state)
print(json.dumps({'completion_signature': str(inspect.signature(goal.check_completion)),
    'state_energy': state.get('energy'), 'expected_satisfied': True,
    'actual_satisfied': actual}), flush=True)
assert state.get('energy') >= 30
assert actual is True, 'Full Character Goal must recognize a satisfied planner state'
''',
'planner_already_satisfied': goal + action + '''state = State({'energy': 30})
plan = planner.plan_actions(character, goal, state, [action])
print(json.dumps({'initial_energy': state.get('energy'),
    'target_energy': 30, 'actual_plan': None if plan is None else [a.name for a in plan],
    'expected_plan': []}), flush=True)
assert state.get('energy') >= 30
assert plan == [], 'An initially satisfied goal requires an empty successful plan'
''',
'planner_reachable': goal + action + '''state = State({'energy': 20})
plan = planner.plan_actions(character, goal, state, [action])
print(json.dumps({'initial_energy': state.get('energy'), 'target_energy': 30,
    'actual_plan': None if plan is None else [a.name for a in plan]}), flush=True)
assert plan, 'Reachable energy goal requires a nonempty usable plan'
final_state = State(state.dict_or_obj.copy())
for selected in plan:
    assert selected is action
    final_state = selected.apply_effects(final_state)
print(json.dumps({'final_energy': final_state.get('energy')}), flush=True)
assert final_state.get('energy') >= 30
assert planner._goal_satisfied(goal, final_state) is True
''',
'planner_unreachable': goal + '''state = State({'energy': 20})
plan = planner.plan_actions(character, goal, state, [])
control = planner._goal_satisfied(goal, State({'energy': 30}))
print(json.dumps({'initial_energy': state.get('energy'), 'available_actions': [],
    'actual_plan': plan, 'expected_no_plan': None, 'satisfied_control': control}), flush=True)
assert plan is None, 'Unreachable goal must report the documented no-plan result'
assert state.get('energy') == 20
assert control is True, 'No-plan is insufficient when all completion checks are broken'
''',
'planner_blocked_preconditions': goal + '''blocked = Condition('unavailable_energy', 'energy', character, 21)
action = Action('BlockedRecovery', [blocked],
    [{'targets': ['initiator'], 'attribute': 'energy', 'change_value': 10}],
    initiator=character, graph_manager=graph)
state = State({'energy': 20})
assert blocked.check_condition() is False
with patch.object(action, 'preconditions_met', wraps=action.preconditions_met) as observed:
    plan = planner.plan_actions(character, goal, state, [action])
    checked = observed.call_count
control = planner._goal_satisfied(goal, State({'energy': 30}))
print(json.dumps({'precondition_checks': checked, 'actual_plan': plan,
    'initial_energy': 20, 'final_state_energy': state.get('energy'),
    'final_character_energy': character.energy, 'satisfied_control': control}), flush=True)
assert checked > 0 and plan is None
assert state.get('energy') == 20 and character.energy == 20
assert control is True, 'Blocked-action result also requires a working goal completion control'
''',
'planner_cost_selection': goal + '''expensive = Action('ExpensiveRecovery', [],
    [{'attribute': 'energy', 'change_value': 10}], cost=5, graph_manager=graph)
cheap = Action('CheapRecovery', [],
    [{'attribute': 'energy', 'change_value': 10}], cost=1, graph_manager=graph)
state = State({'energy': 20})
assert state.get('energy') < 30
plan = planner.plan_actions(character, goal, state, [expensive, cheap])
print(json.dumps({'initial_energy': 20, 'target_energy': 30,
    'input_order': [expensive.name, cheap.name],
    'input_costs': [expensive.cost, cheap.cost],
    'actual_plan': None if plan is None else [a.name for a in plan]}), flush=True)
assert plan, 'Equal-effect cost comparison requires a plan to an unsatisfied target'
assert plan == [cheap] and sum(a.cost for a in plan) == 1
final_state = State(state.dict_or_obj.copy())
for selected in plan:
    final_state = selected.apply_effects(final_state)
assert final_state.get('energy') >= 30
assert planner._goal_satisfied(goal, final_state) is True
''',
'graph_state_provenance': '''node_data = next(data for node, data in graph.G.nodes(data=True) if node is character)
node_data['energy'] = 77
assert character.energy == 20
with patch.object(graph, 'get_character_state', wraps=graph.get_character_state) as observed:
    retrieved = planner.get_current_world_state(character)
    observed.assert_called_once_with(character.name)
print(json.dumps({'graph_energy': node_data['energy'], 'character_energy': character.energy,
    'retrieved_energy': retrieved.get('energy'),
    'retrieved_backing_type': type(retrieved.dict_or_obj).__name__,
    'registered_by_object_identity': any(node is character for node in graph.G)}), flush=True)
assert retrieved.get('energy') == node_data['energy'], 'Planner must use authoritative graph state'
''',
'graph_action_provenance': action + '''# Fixture edges and interaction data use actual registered domain objects.
neighbor = next(node for node in graph.G if node is not character and hasattr(node, 'get_possible_interactions'))
neighbor.possible_interactions = [action]
graph.G.add_edge(character, neighbor, type='available_interaction')
assert graph.G.has_edge(character, neighbor)
assert neighbor.get_possible_interactions() == [action]
with patch.object(graph, 'get_possible_actions', wraps=graph.get_possible_actions) as observed:
    retrieved = planner.get_available_actions(character)
    observed.assert_called_once_with(character.name)
print(json.dumps({'registered_interaction': action.name,
    'registered_cost': action.cost, 'retrieved_names': [a.name for a in retrieved],
    'retrieved_effects': [a.effects for a in retrieved]}), flush=True)
assert [a.name for a in retrieved] == [action.name], 'Graph action retrieval must preserve interaction provenance'
assert retrieved[0].effects == action.effects and retrieved[0].cost == action.cost
''',
'graph_executed_world': action + '''node_data = next(data for node, data in graph.G.nodes(data=True) if node is character)
assert character.energy == node_data['energy'] == 20
with patch.object(graph, 'update_node_attribute', wraps=graph.update_node_attribute) as observed:
    success = action.execute(character=character, graph_manager=graph)
    update_calls = [(str(call.args[0]), *call.args[1:]) for call in observed.call_args_list]
print(json.dumps({'success': success, 'object_energy': character.energy,
    'graph_energy': node_data['energy'], 'expected_final_energy': 30,
    'graph_update_calls': update_calls}), flush=True)
assert success is True and character.energy >= 30
assert node_data['energy'] >= 30, 'Executed action must update authoritative graph state'
''',
'graph_character_identity': '''before = hash(character)
assert graph.G.has_node(character)
character.energy += 1
after = hash(character)
print(json.dumps({'hash_before': before, 'hash_after': after,
    'same_registered_object': any(node is character for node in graph.G),
    'lookup_after_energy_change': graph.G.has_node(character)}), flush=True)
assert graph.G.has_node(character), 'Registered Character lookup must survive a gameplay state change'
assert graph.G.nodes[character]['energy'] == 20
''',
'planner_replan_boolean': goal + action + '''plan = Plan('recover', graph_manager=None)
plan.add_goal(goal)
plan.add_action(action)
result = plan.replan()
print(json.dumps({'replan_result': result, 'expected_type': 'bool',
    'retained_actions': [entry[2].name for entry in plan.action_queue]}), flush=True)
assert type(result) is bool, 'Plan.replan must report success or failure explicitly'
''',
'planner_plan_evaluate': goal + '''plan = Plan('recover', graph_manager=graph)
plan.add_goal(goal)
assert character.energy < 30
print(json.dumps({'energy': character.energy, 'target_energy': 30,
    'expected_evaluation': False}), flush=True)
assert plan.evaluate() is False
''',
'planner_plan_utility': goal + action + '''plan = Plan('recover', graph_manager=graph)
plan.add_goal(goal)
plan.add_action(action)
print(json.dumps({'plan_type': type(plan).__name__,
    'candidate_expected_result': 'finite numeric plan utility'}), flush=True)
result = planner.evaluate_utility(plan, character)
assert isinstance(result, (int, float)) and __import__('math').isfinite(result)
''',
'planner_goal_feasibility': goal + '''state = State({'energy': 20})
print(json.dumps({'energy': state.get('energy'), 'target_energy': 30,
    'candidate_expected_result': 'boolean or numeric feasibility'}), flush=True)
result = planner.evaluate_feasibility_of_goal(goal, state)
assert isinstance(result, (bool, int, float))
''',
}
# Action provenance needs a real neighbor with interactions; use two Characters.
for name, body in cases.items():
    start = setup
    if name == 'graph_action_provenance':
        start = start.replace("'count': 1", "'count': 2")
        start = start.replace("'job': 'unemployed', 'energy': 20}]", "'job': 'unemployed', 'energy': 20},\n            {'name': 'ContractNeighbor', 'age': 31, 'job': 'unemployed', 'energy': 20}]")
    path = root / (name + '.py.txt')
    path.write_text(start + textwrap.indent(body, '    ') + '\nfinally:\n    controller.close()\n')
print('Wrote', len(cases), 'self-contained blocked reproductions')
