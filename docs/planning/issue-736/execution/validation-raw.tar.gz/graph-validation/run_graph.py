import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import unittest

REPO = Path('/workspace/tiny_village')
sys.path.insert(0, str(REPO))
from tests.subprocess_capture import capture_python, CapturedTimeout

profile = sys.argv[1]
mode = sys.argv[2]
root = Path('/workspace/scratch/issue-736/execution/graph-validation') / profile
root.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env.update(TINY_TEST_ARTIFACT_DIR=str(root / 'captures'),
    SDL_VIDEODRIVER='dummy', SDL_AUDIODRIVER='dummy',
    PYGAME_HIDE_SUPPORT_PROMPT='1', PYTHONDONTWRITEBYTECODE='1',
    OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2')
os.environ.update(env)
if mode == 'passing':
    suite = unittest.defaultTestLoader.loadTestsFromName('tests.test_goap_graph_contracts')
    methods = []
    def collect(s):
        for test in s:
            if isinstance(test, unittest.TestSuite): collect(test)
            else: methods.append(test.id())
    collect(suite)
    (root / 'passing-collection.json').write_text(json.dumps(methods, indent=2)+'\n')
    with (root / 'passing-stderr.log').open('w') as output:
        result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    data = {'profile': profile, 'interpreter': sys.executable,
        'python': platform.python_version(), 'tests_run': result.testsRun,
        'failures': len(result.failures), 'errors': len(result.errors),
        'skips': len(result.skipped), 'successful': result.wasSuccessful()}
    (root / 'passing-result.json').write_text(json.dumps(data, indent=2)+'\n')
    print(json.dumps(data))
    sys.exit(not result.wasSuccessful())
rows = []
for path in sorted((REPO / 'docs/planning/issue-736/execution/blocked').glob('*.py.txt')):
    if not path.name.startswith(('planner_', 'graph_')): continue
    source = path.read_text()
    record = {'source': str(path.relative_to(REPO)),
        'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
        'profile': profile, 'interpreter': sys.executable,
        'command': f'{sys.executable} < {path.relative_to(REPO)}',
        'diagnostic_timeout': 20, 'parent_timeout': 25}
    try:
        captured = capture_python(source, cwd=REPO, env=env,
            test_id='issue736.blocked.'+path.name, fatal_timeout=20, timeout=25)
        record.update(returncode=captured.completed.returncode,
            artifact_dir=str(captured.artifact_dir), outcome='UNFULFILLED' if captured.completed.returncode else 'PASS')
        print(path.name, captured.completed.returncode,
            captured.completed.stderr.strip().splitlines()[-1] if captured.completed.stderr.strip() else '')
    except CapturedTimeout as error:
        record.update(returncode=None, artifact_dir=str(error.artifact_dir), outcome='TIMEOUT')
        print(path.name, 'TIMEOUT')
    rows.append(record)
    (root / 'blocked-results.json').write_text(json.dumps(rows, indent=2)+'\n')
