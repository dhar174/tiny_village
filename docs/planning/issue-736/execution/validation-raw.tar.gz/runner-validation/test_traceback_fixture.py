import unittest
def inner_736():
    raise RuntimeError("controlled-full-trace-736")
def outer_736():
    inner_736()
class TracebackFixture(unittest.TestCase):
    def test_traceback(self):
        outer_736()
